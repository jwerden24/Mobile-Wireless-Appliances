import React from "react";
import "./ProfileCard.css"; // Styling for the component
import profileImage from "../assets/images/profile.jpg";

function ProfileCard() {
  return (
    <div className="profile-card">
      <img src={profileImage} alt="Profile" className="profile-image" />
      <h1 className="profile-name">Jack</h1>
      <p className="profile-email">
        <a href="mailto:jwerden@hgtc.edu">jwerden@hgtc.edu</a>
      </p>
      <p className="profile-phone">
        <a href="tel:+8437815001">(843) 781-5001</a>
      </p>
      <p className="profile-github">
        <a href="https://github.com/jwerden24/Mobile-Wireless-Appliances.git" target="_blank" rel="noopener noreferrer">
          GitHub Profile
        </a>
      </p>
    </div>
  );
}

export default ProfileCard;