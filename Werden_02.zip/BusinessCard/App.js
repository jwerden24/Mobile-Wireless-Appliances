import React from "react";
import ProfileCard from "./components/ProfileCard";
import "./App.css"; // Optional: for global styles

function App() {
  return (
    <div className="app-container">
      <ProfileCard />
    </div>
  );
}

export default App;