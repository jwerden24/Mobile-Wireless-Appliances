const colors = {
    primary: "#D35400",  // Warm orange for buttons/titles
    secondary: "#2C3E50", // Dark blue-gray for text
    background: "#F4F1EA", // Light cream for background
    accent: "#27AE60", // Green for highlights
  };
  
  export default colors;
  