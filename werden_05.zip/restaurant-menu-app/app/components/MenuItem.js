import React from "react";
import { View, Text, Image, StyleSheet } from "react-native";

const MenuItem = ({ name, image, price }) => (
  <View style={styles.container}>
    <Image source={image} style={styles.image} />
    <Text style={styles.name}>{name}</Text>
    <Text style={styles.price}>{price}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { alignItems: "center", marginVertical: 10 },
  image: { width: 150, height: 100, borderRadius: 10 },
  name: { fontSize: 18, marginTop: 5 },
  price: { fontSize: 16, color: "gray" },
});

export default MenuItem;
