import React from "react";
import { View, Text, Image, TouchableOpacity, Linking, StyleSheet } from "react-native";
import Title from "../components/Title";
import colors from "../constants/colors";

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Image source={require("../assets/images/restaurant.jpg")} style={styles.image} />
      <Title text="Gourmet Delight" />
      
      <Text style={styles.details} onPress={() => Linking.openURL("tel:123456789")}>
        📞 123-456-789
      </Text>
      <Text style={styles.details} onPress={() => Linking.openURL("https://gourmetdelight.com")}>
        🌐 gourmetdelight.com
      </Text>
      <Text style={styles.details} onPress={() => Linking.openURL("https://maps.google.com/?q=Restaurant+Address")}>
        📍 123 Food Street, Culinary City
      </Text>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Menu")}>
        <Text style={styles.buttonText}>View Menu</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background },
  image: { width: 300, height: 200, borderRadius: 10, marginBottom: 20 },
  details: { fontSize: 16, color: colors.primary, marginBottom: 10 },
  button: { backgroundColor: colors.primary, padding: 10, borderRadius: 5 },
  buttonText: { color: "#fff", fontSize: 18 },
});

export default HomeScreen;
