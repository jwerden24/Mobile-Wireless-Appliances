import React from "react";
import { View, FlatList, StyleSheet, TouchableOpacity, Text } from "react-native";
import MenuItem from "../components/MenuItem";
import Title from "../components/Title";
import colors from "../constants/colors";

const menuItems = [
  { id: "1", name: "Spaghetti Carbonara", image: require("../assets/images/menu-item1.jpg"), price: "$12.99" },
  { id: "2", name: "Grilled Salmon", image: require("../assets/images/menu-item2.jpg"), price: "$18.99" },
  { id: "3", name: "Caesar Salad", image: require("../assets/images/menu-item3.jpg"), price: "$8.99" },
  { id: "4", name: "Tiramisu", image: require("../assets/images/menu-item4.jpg"), price: "$6.99" },
  { id: "5", name: "Lemonade", image: require("../assets/images/menu-item5.jpg"), price: "$3.99" },
];

const MenuScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Title text="Menu" />
      <FlatList data={menuItems} renderItem={({ item }) => <MenuItem {...item} />} keyExtractor={(item) => item.id} />
      <TouchableOpacity style={styles.button} onPress={() => navigation.goBack()}>
        <Text style={styles.buttonText}>Back to Home</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: colors.background },
  button: { marginTop: 20, backgroundColor: colors.primary, padding: 10, borderRadius: 5, alignItems: "center" },
  buttonText: { color: "#fff", fontSize: 18 },
});

export default MenuScreen;
