import React, { useState } from "react";
import { View, Text, ImageBackground, ScrollView, Switch, StyleSheet } from "react-native";
import RadioGroup from "react-native-radio-buttons-group";
import Checkbox from "@react-native-community/checkbox";
import Title from "../components/Title";
import NavigationButton from "../components/NavigationButton";

const HomeScreen = ({ navigation }) => {
  const [selectedServiceTime, setSelectedServiceTime] = useState("Standard ($0)");
  const [services, setServices] = useState([]);
  const [newsletter, setNewsletter] = useState(false);
  const [membership, setMembership] = useState(false);

  return (
    <ImageBackground source={require("../assets/background.jpg")} style={styles.background}>
      <ScrollView contentContainerStyle={styles.container}>
        <Title text="Bicycle Repair Shop" />
        <Text>Service Time:</Text>
        <RadioGroup
          radioButtons={[
            { label: "Standard ($0)", value: "Standard ($0)" },
            { label: "Expedited ($50)", value: "Expedited ($50)" },
            { label: "Next Day ($100)", value: "Next Day ($100)" },
          ]}
          onPress={setSelectedServiceTime}
          selectedId={selectedServiceTime}
        />
        <Text>Newsletter Signup:</Text>
        <Switch value={newsletter} onValueChange={setNewsletter} />
        <NavigationButton title="Review Order" onPress={() => navigation.navigate("OrderReview")} />
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  background: { flex: 1, resizeMode: "cover" },
  container: { padding: 20 },
});

export default HomeScreen;
