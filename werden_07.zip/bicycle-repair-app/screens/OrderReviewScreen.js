import React from "react";
import { View, Text, StyleSheet } from "react-native";
import NavigationButton from "../components/NavigationButton";

const OrderReviewScreen = ({ route, navigation }) => {
  const { selectedServiceTime, services, newsletter, membership } = route.params;
  return (
    <View style={styles.container}>
      <Text>Order Review</Text>
      <Text>Service Time: {selectedServiceTime}</Text>
      <NavigationButton title="Return Home" onPress={() => navigation.navigate("Home")} />
    </View>
  );
};

const styles = StyleSheet.create({ container: { flex: 1, padding: 20 } });

export default OrderReviewScreen;
