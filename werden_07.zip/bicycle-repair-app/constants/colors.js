export default {
    primary: "#007bff", // Main button & highlight color
    secondary: "#ff6f61", // Accent color
    background: "#f8f9fa", // Light gray background
    text: "#333", // Dark text
    white: "#ffffff",
    black: "#000000",
    gradientStart: "#6a11cb", // Gradient start (for Order Review Screen)
    gradientEnd: "#2575fc", // Gradient end
  };
  