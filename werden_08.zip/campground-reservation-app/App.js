import { useEffect, useState } from "react";
import { Text, View } from "react-native";
import * as Font from "expo-font";
import AppLoading from "expo-app-loading";
import HomeScreen from "./screens/HomeScreen";

export default function App() {
    const [fontsLoaded, setFontsLoaded] = useState(false);

    useEffect(() => {
        Font.loadAsync({
            "Lobster-Regular": require("./assets/fonts/Lobster-Regular.ttf"),
            "OpenSans-Regular": require("./assets/fonts/OpenSans-Regular.ttf"),
        }).then(() => setFontsLoaded(true));
    }, []);

    if (!fontsLoaded) {
        return <AppLoading />;
    }

    return <HomeScreen />;
}