import React from "react";
import { TouchableOpacity, Text, StyleSheet } from "react-native";

export default function ReserveButton({ onPress }) {
    return (
        <TouchableOpacity style={styles.button} onPress={onPress}>
            <Text style={styles.buttonText}>Reserve Now</Text>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button: {
        backgroundColor: "#ff8c00",
        padding: 15,
        borderRadius: 10,
        marginTop: 20,
        alignItems: "center"
    },
    buttonText: {
        fontSize: 18,
        color: "#fff",
        fontFamily: "OpenSans-Regular"
    }
});
