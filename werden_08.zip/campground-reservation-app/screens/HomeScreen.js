import React, { useState } from "react";
import { View, Text, TouchableOpacity, ImageBackground } from "react-native";
import DateTimePickerModal from "react-native-modal-datetime-picker";
import WheelPicker from "react-native-wheel-picker-android";
import Title from "../components/Title";
import ReserveButton from "../components/ReserveButton";
import styles from "../styles/HomeScreenStyles";

export default function HomeScreen() {
    const [checkIn, setCheckIn] = useState("Select Check-In Date");
    const [checkOut, setCheckOut] = useState("Select Check-Out Date");
    const [guests, setGuests] = useState(1);
    const [campsites, setCampsites] = useState(1);

    const [datePickerVisible, setDatePickerVisible] = useState(false);
    const [isSelectingCheckIn, setIsSelectingCheckIn] = useState(true);
    const [guestPickerVisible, setGuestPickerVisible] = useState(false);
    const [campsitePickerVisible, setCampsitePickerVisible] = useState(false);

    const handleConfirmDate = (date) => {
        if (isSelectingCheckIn) {
            setCheckIn(date.toLocaleDateString());
        } else {
            setCheckOut(date.toLocaleDateString());
        }
        setDatePickerVisible(false);
    };

    return (
        <ImageBackground source={require("../assets/background.jpg")} style={styles.background}>
            <View style={styles.container}>
                <Title text="Campground Reservations" />
                
                <TouchableOpacity onPress={() => { setIsSelectingCheckIn(true); setDatePickerVisible(true); }}>
                    <Text style={styles.label}>{checkIn}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => { setIsSelectingCheckIn(false); setDatePickerVisible(true); }}>
                    <Text style={styles.label}>{checkOut}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => setGuestPickerVisible(true)}>
                    <Text style={styles.label}>Guests: {guests}</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={() => setCampsitePickerVisible(true)}>
                    <Text style={styles.label}>Campsites: {campsites}</Text>
                </TouchableOpacity>

                <ReserveButton onPress={() => alert(`Reserved: ${checkIn} to ${checkOut}, ${guests} guests, ${campsites} campsites`)} />

                {/* Date Picker */}
                <DateTimePickerModal
                    isVisible={datePickerVisible}
                    mode="date"
                    onConfirm={handleConfirmDate}
                    onCancel={() => setDatePickerVisible(false)}
                />

                {/* Guest Picker */}
                {guestPickerVisible && (
                    <WheelPicker
                        selectedItem={guests - 1}
                        data={[...Array(15).keys()].map(i => (i + 1).toString())}
                        onItemSelected={(index) => { setGuests(index + 1); setGuestPickerVisible(false); }}
                    />
                )}

                {/* Campsite Picker */}
                {campsitePickerVisible && (
                    <WheelPicker
                        selectedItem={campsites - 1}
                        data={["1", "2", "3", "4", "5"]}
                        onItemSelected={(index) => { setCampsites(index + 1); setCampsitePickerVisible(false); }}
                    />
                )}
            </View>
        </ImageBackground>
    );
}
