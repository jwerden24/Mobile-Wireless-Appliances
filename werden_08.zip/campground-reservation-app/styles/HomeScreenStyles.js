import { StyleSheet } from "react-native";

export default StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center",
        padding: 20
    },
    background: {
        flex: 1,
        resizeMode: "cover",
        justifyContent: "center"
    },
    label: {
        fontSize: 20,
        color: "#fff",
        marginBottom: 15
    }
});
