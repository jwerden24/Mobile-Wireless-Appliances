import React from "react";
import { movies } from "./components/movies";
import MovieCard from "./components/moviecard";
import "./App.css";

const App = () => {
  return (
    <div className="app-container">
      <h1 className="app-title">👻 Top 10 Horror Movies</h1>
      <div className="movie-list">
        {movies.map((movie) => (
          <MovieCard
            key={movie.id}
            title={movie.title}
            poster={movie.poster}
            rating={movie.rating}
          />
        ))}
      </div>
    </div>
  );
};

export default App;