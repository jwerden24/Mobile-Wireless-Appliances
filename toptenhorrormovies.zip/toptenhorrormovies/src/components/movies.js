export const movies = [
    {
      id: "1",
      title: "Hereditary (2018)",
      poster: "/assets/hereditary.jpg",
      rating: "8.1",
    },
    {
      id: "2",
      title: "Get Out (2017)",
      poster: "/assets/getout.jpg",
      rating: "7.8",
    },
    {
      id: "3",
      title: "The Witch (2015)",
      poster: "/assets/thewitch.jpg",
      rating: "6.9",
    },
    {
      id: "4",
      title: "It Follows (2014)",
      poster: "/assets/itfollows.jpg",
      rating: "6.8",
    },
    {
      id: "5",
      title: "A Quiet Place (2018)",
      poster: "/assets/aquietplace.jpg",
      rating: "7.5",
    },
    {
      id: "6",
      title: "The Conjuring (2013)",
      poster: "/assets/theconjuring.jpg",
      rating: "7.5",
    },
    {
      id: "7",
      title: "The Babadook (2014)",
      poster: "/assets/thebabadook.jpg",
      rating: "6.8",
    },
    {
      id: "8",
      title: "Sinister (2012)",
      poster: "/assets/sinister.jpg",
      rating: "6.8",
    },
    {
      id: "9",
      title: "The Invisible Man (2020)",
      poster: "/assets/theinvisibleman.jpg",
      rating: "7.1",
    },
    {
      id: "10",
      title: "Talk to Me (2023)",
      poster: "/assets/talktome.jpg",
      rating: "7.2",
    },
  ];