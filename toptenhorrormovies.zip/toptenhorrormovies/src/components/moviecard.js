import React from "react";
import "./moviecard.css";

const MovieCard = ({ title, poster, rating }) => {
  return (
    <div className="movie-card">
      <img src={poster} alt={title} className="movie-image" />
      <h3 className="movie-title">{title}</h3>
      <p className="movie-rating">⭐ {rating}</p>
    </div>
  );
};

export default MovieCard;