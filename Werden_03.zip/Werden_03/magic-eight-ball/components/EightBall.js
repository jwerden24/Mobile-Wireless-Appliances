import React, { useState, useEffect } from "react";
import { View, Text, StyleSheet } from "react-native";
import QuestionInput from "../../components/QuestionInput";
import ResponseDisplay from "../../components/ResponseDisplay";

const EightBall = () => {
  const [responses, setResponses] = useState([]);
  const [question, setQuestion] = useState("");
  const [response, setResponse] = useState("");

  useEffect(() => {
    import("../../assets/MagicEightBallResponses.txt")
      .then((res) => fetch(res.default))
      .then((res) => res.text())
      .then((text) => setResponses(text.split("\n").filter((line) => line.trim())))
      .catch((err) => console.error("Error loading responses:", err));
  }, []);

  const handleQuestionSubmit = (userQuestion) => {
    if (responses.length > 0) {
      const randomResponse = responses[Math.floor(Math.random() * responses.length)];
      setQuestion(userQuestion);
      setResponse(randomResponse);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Magic Eight Ball</Text>
      <QuestionInput onSubmit={handleQuestionSubmit} />
      <ResponseDisplay question={question} response={response} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center", padding: 20 },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
});

export default EightBall;
