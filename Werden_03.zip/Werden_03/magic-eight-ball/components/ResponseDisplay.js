import React from "react";
import { View, Text, StyleSheet } from "react-native";

const ResponseDisplay = ({ question, response }) => {
  return (
    <View style={styles.container}>
      {question ? <Text style={styles.question}>You Asked: {question}</Text> : null}
      {response ? <Text style={styles.response}>Magic 8 Ball Says: {response}</Text> : null}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { margin: 20 },
  question: { fontSize: 18, fontWeight: "bold", marginBottom: 10 },
  response: { fontSize: 18, color: "blue" },
});

export default ResponseDisplay;
