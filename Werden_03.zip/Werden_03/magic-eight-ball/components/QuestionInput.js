import React, { useState } from "react";
import { View, TextInput, Button, StyleSheet } from "react-native";

const QuestionInput = ({ onSubmit }) => {
  const [question, setQuestion] = useState("");

  const handleSubmit = () => {
    if (question.trim()) {
      onSubmit(question);
      setQuestion("");
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        value={question}
        onChangeText={setQuestion}
        placeholder="Ask the Magic 8 Ball..."
      />
      <Button title="Ask" onPress={handleSubmit} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { margin: 20 },
  input: { borderWidth: 1, padding: 10, marginBottom: 10, width: "100%" },
});

export default QuestionInput;
