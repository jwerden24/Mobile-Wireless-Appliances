import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import Title from "../components/Title";

export default function RecipeModal({ route, navigation }) {
  const { item } = route.params;

  return (
    <View style={styles.container}>
      <Title>{item.title}</Title>
      <Text style={styles.text}>{item.text}</Text>
      <Button title="Back to Recipes" onPress={() => navigation.goBack()} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  text: { fontSize: 18, marginTop: 10 },
});
