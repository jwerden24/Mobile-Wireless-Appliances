import React from "react";
import { View, FlatList, Button, StyleSheet } from "react-native";
import RecipeItem from "../components/RecipeItem";

export default function RecipesScreen({ navigation, recipes, setRecipes }) {
  const deleteRecipe = (id) => {
    setRecipes(recipes.filter((recipe) => recipe.id !== id));
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <RecipeItem item={item} navigation={navigation} onDelete={deleteRecipe} />
        )}
      />
      <Button title="Add Recipe" onPress={() => navigation.navigate("Add Recipe")} />
      <Button title="Home" onPress={() => navigation.navigate("Home")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
});
