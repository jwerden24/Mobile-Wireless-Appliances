import React, { useState } from "react";
import { View, TextInput, Button, StyleSheet } from "react-native";

export default function AddRecipeScreen({ navigation, setRecipes }) {
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");

  const saveRecipe = () => {
    if (title && text) {
      setRecipes((prevRecipes) => [...prevRecipes, { id: Date.now().toString(), title, text }]);
      navigation.goBack();
    }
  };

  return (
    <View style={styles.container}>
      <TextInput placeholder="Recipe Title" value={title} onChangeText={setTitle} style={styles.input} />
      <TextInput placeholder="Recipe Text" value={text} onChangeText={setText} style={styles.input} multiline />
      <Button title="Save" onPress={saveRecipe} />
      <Button title="Cancel" onPress={() => navigation.goBack()} color="red" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  input: { borderWidth: 1, padding: 10, marginBottom: 10 },
});
