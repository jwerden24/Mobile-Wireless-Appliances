import React from "react";
import { View, Image, Button, StyleSheet } from "react-native";
import Title from "../components/Title";

export default function MainScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Title>Recipes App</Title>
      <Image source={require("../assets/recipes.jpg")} style={styles.image} />
      <Button title="View Recipes" onPress={() => navigation.navigate("Recipes")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center" },
  image: { width: 200, height: 200, marginBottom: 20 },
});
