import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";

export default function RecipeItem({ item, navigation, onDelete }) {
  return (
    <View style={styles.item}>
      <Text style={styles.title}>{item.title}</Text>
      <Button title="View" onPress={() => navigation.navigate("Recipe Modal", { item })} />
      <Button title="Delete" onPress={() => onDelete(item.id)} color="red" />
    </View>
  );
}

const styles = StyleSheet.create({
  item: { flexDirection: "row", justifyContent: "space-between", padding: 10, borderBottomWidth: 1 },
  title: { fontSize: 18 },
});
