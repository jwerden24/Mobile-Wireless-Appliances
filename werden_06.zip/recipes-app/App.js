import React, { useState } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import MainScreen from "./app/MainScreen";
import RecipesScreen from "./app/RecipesScreen";
import AddRecipeScreen from "./app/AddRecipeScreen";
import RecipeModal from "./app/RecipeModal";

const Stack = createStackNavigator();

export default function App() {
  const [recipes, setRecipes] = useState([
    { id: "1", title: "Spaghetti", text: "Boil pasta and add sauce." },
    { id: "2", title: "Pancakes", text: "Mix batter and fry on pan." },
  ]);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home">
          {(props) => <MainScreen {...props} />}
        </Stack.Screen>
        <Stack.Screen name="Recipes">
          {(props) => <RecipesScreen {...props} recipes={recipes} setRecipes={setRecipes} />}
        </Stack.Screen>
        <Stack.Screen name="Add Recipe">
          {(props) => <AddRecipeScreen {...props} setRecipes={setRecipes} />}
        </Stack.Screen>
        <Stack.Screen name="Recipe Modal" component={RecipeModal} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
